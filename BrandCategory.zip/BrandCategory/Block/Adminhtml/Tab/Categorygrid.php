<?php
/**
 * Created By : RH
 */
namespace Zestardtech\BrandCategory\Block\Adminhtml\Tab;

use Magento\Catalog\Model\Product\Visibility;
use Magento\Framework\App\ObjectManager;
use Magento\Store\Model\Store;

class Categorygrid extends \Magento\Backend\Block\Widget\Grid\Extended
{

    /**
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry = null;

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $productFactory;
    protected $categoryCollection;

    /**
     * @var \Zestardtech\BrandCategory\Model\ResourceModel\Product\CollectionFactory
     */
    protected $productCollFactory;

    /**
     * @param \Magento\Backend\Block\Template\Context    $context
     * @param \Magento\Backend\Helper\Data               $backendHelper
     * @param \Magento\Catalog\Model\ProductFactory      $productFactory
     * @param \Magento\Framework\Registry                $coreRegistry
     * @param \Magento\Framework\Module\Manager          $moduleManager
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param Visibility|null                            $visibility
     * @param array                                      $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Catalog\Model\CategoryFactory  $categoryFactory,
        \Zestardtech\BrandCategory\Model\ResourceModel\BrandCategory\CollectionFactory $ruleCategoryCollection,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\Module\Manager $moduleManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        Visibility $visibility = null,
        array $data = []
    ) {

        $this->categoryFactory = $categoryFactory;
        $this->productFactory = $productFactory;
        $this->ruleCategoryCollection = $ruleCategoryCollection;
        $this->coreRegistry = $coreRegistry;
        $this->moduleManager = $moduleManager;
        $this->_storeManager = $storeManager;
        $this->visibility = $visibility ?: ObjectManager::getInstance()->get(Visibility::class);
        parent::__construct($context, $backendHelper, $data);
    }

    /**
     * [_construct description]
     * @return [type] [description]
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('rh_grid_categories');
        $this->setDefaultSort('name');
        $this->setDefaultDir('ASC');
        $this->setUseAjax(true);
        /*if ($this->getRequest()->getParam('entity_id')) {
            $this->setDefaultFilter(['in_products' => 1]);
        } else {
            $this->setDefaultFilter(['in_products' => 0]);
        }*/
        $this->setSaveParametersInSession(true);
    }

    /**
     * [get store id]
     *
     * @return Store
     */
    protected function _getStore()
    {
        $storeId = (int) $this->getRequest()->getParam('store', 0);
        return $this->_storeManager->getStore($storeId);
    }

    
    protected function _prepareCollection()
    {
        $store = $this->_getStore();

        $collection = $this->categoryFactory->create()
            ->getCollection()
            ->addAttributeToSelect('*');

        $collection->getSelect()
            ->reset(\Zend_Db_Select::COLUMNS)
            ->columns(['entity_id']);
            
        $collection->addAttributeToSelect('*')
            ->addFieldToFilter('name', ["neq"=>null])
            ->addFieldToFilter('is_active', 1);


        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    
    protected function _addColumnFilterToCollection($column)
    {
        // Set custom filter for in category flag
        if ($column->getId() == 'in_categories') {
            $categoryIds = $this->_getSelectedCategories();
            if (empty($categoryIds)) {
                $categoryIds = 0;
            }
            if ($column->getFilter()->getValue()) {
                $this->getCollection()->addFieldToFilter('entity_id', ['in' => $categoryIds]);
            } elseif (!empty($categoryIds)) {
                $this->getCollection()->addFieldToFilter('entity_id', ['nin' => $categoryIds]);
            }
        } else {
            parent::_addColumnFilterToCollection($column);
        }
        return $this;
    }

    /**
     * @return Extended
     */
    protected function _prepareColumns()
    {
        $this->addColumn(
            "in_categories",
            [
                "type"     => "checkbox",
                "name"     => "in_categories",
                "align"    => "center",
                "width"    => "100px",
                "index"    => "entity_id",
                "values"   => $this->_getSelectedCategories(),
                "header"   => __("Select"),
                "sortable" => false
            ]
        );

        $this->addColumn(
            "entity_id",
            [
                "type"     => "number",
                "align"    => "center",
                "width"    => "30px",
                "index"    => "entity_id",
                "header"   => __("ID")
            ]
        );

        $this->addColumn(
            "name",
            [
                "index"    => "name",
                "align"    => "left",
                "header"   => __("Category Name")
            ]
        );


         $this->addColumn(
            'position',
            [
                'header' => __('Position'),
                'name' => 'position',
                'type' => 'number',
                "width"    => "30px",
                'validate_class' => 'validate-number',
                'index' => 'position',
                'values' => $this->getCategoriesPosition(),
                'editable' => true,
               // 'editable' => $this->getCategoriesPosition()

            ]
        );

        $store = $this->_getStore();
       /* $this->addColumn(
            'price',
            [
                'header' => __('Price'),
                'type' => 'price',
                'currency_code' => $store->getBaseCurrency()->getCode(),
                'index' => 'price',
                'header_css_class' => 'col-price',
                'column_css_class' => 'col-price',
            ]
        );*/
        /*$this->addColumn(
            'position',
            [
                'header' => __('Position'),
                'name' => 'position',
                'width' => 60,
                'type' => 'number',
                'validate_class' => 'validate-number',
                'index' => 'position',
                'editable' => true,
                'edit_only' => true,
                'editable' => !$this->getProductsPosition()
            ]
        );*/

       

       /* $this->addColumn(
            'product_position',
            [
                'header' => __('Position'),
                'name' => 'product_position',
                'width' => 60,
                'type' => 'number',
                'validate_class' => 'validate-number',
                'index' => 'position',
                'editable' => true,
                'edit_only' => true,
                // 'editable' => $this->getProductsPosition()
            ]
        );*/
          
        return parent::_prepareColumns();
    }

    /**
     * @return string
     */
    public function getGridUrl()
    {
        return $this->getUrl('brandcategory/index/grids', ['_current' => true]);
    }

    /**
     * @return array
     */
    protected function _getSelectedCategories()
    {
        $products = $this->getSelectedCategories();
        //print_r($products);
        //die(); 
        return $products;
    }

    /**
     * @return array
     */
    protected function getCategoriesPosition()
    {
       /* $id = $this->getRequest()->getParam('id');
        $model = $this->productCollFactory->create()->addFieldToFilter('category_id', $id);
        $positions = [];
        foreach ($model as $key => $value) {
            $positions[] = $value->getPosition();
        }*/

         $positions = [];
        $ruleId      = $this->getRequest()->getParam("id");
        $pointsCollection = $this->ruleCategoryCollection->create()
            ->addFieldToFilter("category_id", $ruleId);
        
        foreach ($pointsCollection as $each) {
            $positions[] = $each->getPosition();
        }
        
        //$positions = asort($positions);
        return $positions;
    }

    /**
     * @return array
     */
    public function getSelectedCategories()
    {        
        /*$id = $this->getRequest()->getParam('id');
        $model = $this->productCollFactory->create()->addFieldToFilter('category_id', $id);
        
        $grids = [];
        foreach ($model as $key => $value) {
            $grids[] = $value->getProductId();
        }*/
 
        /*$prodId = [];
        foreach ($grids as $obj) {
            $prodId[$obj] = ['position' => "12"];
        }
        return $prodId;*/


         $categoryIds = [];
        $ruleId      = $this->getRequest()->getParam("id");
        $pointsCollection = $this->ruleCategoryCollection->create()
            ->addFieldToFilter("category_id", $ruleId);
        

        foreach ($pointsCollection as $each) {
            $categoryIds[] = $each['brand_category_id'];
        }

        return $categoryIds;

    }

}