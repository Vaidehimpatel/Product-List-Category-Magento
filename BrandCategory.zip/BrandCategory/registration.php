<?php


use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Zestardtech_BrandCategory', __DIR__);

