

define([
    'mage/adminhtml/grid'
], function () {
    'use strict';

    return function (config) {
        var selectedCategories = config.selectedCategories,
            categoryCategories = $H(selectedCategories),
            gridJsObject = window[config.gridJsObjectName],
            tabIndex = 1000;
        /**
         * Show selected product when edit form in associated product grid
         */
        $('rh_categories').value = Object.toJSON(categoryCategories);

        /**
         * Register Category Product
         *
         * @param {Object} grid
         * @param {Object} element
         * @param {Boolean} checked
         */
        function registerCategoryCategory(grid, element, checked) {

            console.log(grid);
            if (checked) {
                if (element.positionElement) {
                    element.positionElement.disabled = false;
                    categoryCategories.set(element.value, element.positionElement.value);
                }
            } else {
                if (element.positionElement) {
                    element.positionElement.disabled = true;
                }
                categoryCategories.unset(element.value);
            }
            $('rh_categories').value = Object.toJSON(categoryCategories);
            
            grid.reloadParams = {
                'selected_products[]': categoryCategories.keys()
            };

        }

        /**
         * Click on product row
         *
         * @param {Object} grid
         * @param {String} event
         */
      
          function categoryCategoryRowClick(grid, event) {
            var trElement = Event.findElement(event, 'tr'),
                eventElement = Event.element(event),
                isInputCheckbox = eventElement.tagName === 'INPUT' && eventElement.type === 'checkbox',
                isInputPosition = grid.targetElement &&
                    grid.targetElement.tagName === 'INPUT' &&
                    grid.targetElement.name === 'position',
                checked = false,
                checkbox = null;

            if (eventElement.tagName === 'LABEL' &&
                trElement.querySelector('#' + eventElement.htmlFor) &&
                trElement.querySelector('#' + eventElement.htmlFor).type === 'checkbox'
            ) {
                event.stopPropagation();
                trElement.querySelector('#' + eventElement.htmlFor).trigger('click');

                return;
            }

            if (trElement && !isInputPosition) {
                checkbox = Element.getElementsBySelector(trElement, 'input');

                if (checkbox[0]) {
                    checked = isInputCheckbox ? checkbox[0].checked : !checkbox[0].checked;
                    gridJsObject.setCheckboxChecked(checkbox[0], checked);
                }
            }
        }

        /**
         * Change product position
         *
         * @param {String} event
         */
        function positionChange(event) {
            var element = Event.element(event);

            if (element && element.checkboxElement && element.checkboxElement.checked) {
                categoryCategories.set(element.checkboxElement.value, element.value);
                $('rh_categories').value = Object.toJSON(categoryCategories);
            }
        }

        /**
         * Initialize category product row
         *
         * @param {Object} grid
         * @param {String} row
         */
        function categoryCategoryRowInit(grid, row, index) {
            var checkbox = $(row).getElementsByClassName('checkbox')[0],
                position = $(row).getElementsByClassName('input-text')[0];
                var productVal = Object.toJSON(categoryCategories);


                var objval= JSON.parse(productVal); 



            if (checkbox && position) {


                checkbox.positionElement = position;
                position.checkboxElement = checkbox;
                position.disabled = !checkbox.checked;
                position.tabIndex = tabIndex++;
               // position.values = '121';


                if(objval[checkbox.value]!=undefined)
                {
                    position.value = objval[checkbox.value];
                }

/*
                 if(objval[index+1]!=undefined)
                {
                    position.value = objval[index+1];
                }
  
  */
                Event.observe(position, 'keyup', positionChange);
            }
        }

        gridJsObject.rowClickCallback = categoryCategoryRowClick;
        gridJsObject.initRowCallback = categoryCategoryRowInit;
        gridJsObject.checkboxCheckCallback = registerCategoryCategory;

        if (gridJsObject.rows) {
            gridJsObject.rows.each(function (row, index) {
                categoryCategoryRowInit(gridJsObject, row, index);
            });
        }
    };
});