<?php

namespace Zestardtech\BrandCategory\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class CategoryListsaveafter implements ObserverInterface {

    protected $objectManager;
    private $category = null;
    
    public function __construct(
        \Magento\Framework\ObjectManagerInterface $objectManager
    ) {
        $this->objectManager = $objectManager;
    }

    public function execute(EventObserver $observer) {
      
      $categoryId = $observer->getDataObject()->getData('entity_id');
      $vProducts = $observer->getDataObject()->getData('rh_categories');


      if($vProducts == NULL)
      {
        return 0;
      }
      
       $vProducts = json_decode($vProducts);

        $i=0;
        foreach ($vProducts as $key => $value) {
           $vProductId[$i] = $key;
           $vPosition[$i] = $value;
           $i++; 
        }

        $_objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $hkproductModel = $this->objectManager->create('Zestardtech\BrandCategory\Model\BrandCategory');
       
        /**** code for deletion ********/
        $hkproductCollection = $hkproductModel->getCollection()->addFieldToFilter('category_id', $categoryId);
        if($hkproductCollection->count() > 0){
            //$total = $hkproductCollection->count();
            foreach ($hkproductCollection as $production) {
                $production->delete();
            }
        }

        for($j=0; $j<$i; $j++)
        {
           

          $hkproductModel->setData(array('brand_category_id'=>$vProductId[$j], 'category_id' => $categoryId, 'position' => $vPosition[$j]));
          $hkproductModel->save();
        }
  
    }



}