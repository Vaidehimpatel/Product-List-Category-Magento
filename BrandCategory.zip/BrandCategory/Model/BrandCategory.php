<?php

namespace Zestardtech\BrandCategory\Model;

use Magento\Cron\Exception;
use Magento\Framework\Model\AbstractModel;

/**
 * Contact Model
 *
 * @author      Pierre FAY
 */
class BrandCategory extends AbstractModel
{



    const TBL_FEATURED_PRODUCTS = 'zestard_featured_brands';
    /**
     * @var \Magento\Framework\Stdlib\DateTime
     */
    protected $_dateTime;

    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Zestardtech\BrandCategory\Model\ResourceModel\BrandCategory::class);
    }


    public function getProducts(\Zestardtech\BrandCategory\Model\BrandCategory $object, $entityId)
    {
       
        $tbl = $this->getResource()->getTable(
            \Zestardtech\BrandCategory\Model\ResourceModel\BrandCategory::TBL_FEATURED_PRODUCTS
        );
        $select = $this->getResource()->getConnection()->select()
        ->from(
            $tbl,
            ['brand_category_id']
        )->where(
            'category_id = ?',
            $entityId
        );

        //echo '<pre>'; print_r($select->__toString()); die;
        //echo '<pre>'; print_r($this->getResource()->getConnection()->fetchCol($select)); die;
        return $this->getResource()->getConnection()->fetchCol($select);
    }

    
}
