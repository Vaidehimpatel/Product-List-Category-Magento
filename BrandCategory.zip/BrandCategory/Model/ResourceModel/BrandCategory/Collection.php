<?php

namespace Zestardtech\BrandCategory\Model\ResourceModel\BrandCategory;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * Initialize resource collection
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('Zestardtech\BrandCategory\Model\BrandCategory', 'Zestardtech\BrandCategory\Model\ResourceModel\BrandCategory');
    }
}
