<?php

namespace Zestardtech\BrandCategory\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;


class BrandCategory extends AbstractDb
{

    const TBL_FEATURED_PRODUCTS = 'zestard_brand_category';
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('zestard_brand_category', 'id');
    }
}